

package cs301.birthdaycake;


import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.SeekBar;

public class CakeController implements View.OnClickListener, CompoundButton.OnCheckedChangeListener, SeekBar.OnSeekBarChangeListener {
    //instance variables
    private CakeView cv;
    private CakeModel cm;


    public CakeController(CakeView cv) {
        this.cv = cv;
        this.cm = cv.getCakeModel();

    }


    @Override
    public void onClick(View view) {
        Log.d("Blow Out", "click");
        cm.litCandles = false;
        cv.invalidate();
    }


    @Override
    public void onCheckedChanged(CompoundButton cb, boolean b) {
        if(b){
            cm.hasCandles = true;
        }
        else {
            cm.hasCandles = false;
        }
        cv.invalidate();
    }


    @Override
    public void onProgressChanged(SeekBar sb, int i, boolean b) {
        cm.numCandles = i;
        cv.invalidate();
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
