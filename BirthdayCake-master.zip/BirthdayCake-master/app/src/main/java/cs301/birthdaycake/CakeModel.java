package cs301.birthdaycake;

public class CakeModel {
    //instance variables
    public boolean litCandles = true;
    public int numCandles = 2;
    public boolean hasFrosting = true;
    public boolean hasCandles = true;
}
