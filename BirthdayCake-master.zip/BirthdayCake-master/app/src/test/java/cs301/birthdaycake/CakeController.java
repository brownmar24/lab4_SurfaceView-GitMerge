package cs301.birthdaycake;



public class CakeController {
    //instance variables
    private CakeView cv;
    private CakeModel cm;

    public CakeController(CakeView cv) {
        this.cv = cv;
        this.cm = cv.getCakeModel();

    }
}
